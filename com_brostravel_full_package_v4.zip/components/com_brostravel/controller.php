<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class BrostravelController extends BaseController {}
